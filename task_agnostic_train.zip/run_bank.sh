python3 train.py --log_dir log/efl_round5_family --num_steps 50000 --eval_every 5000

python3 train.py --log_dir log/fb15k/efl_round5 \
                 --learning_method efl \
                 --lr 1e-2 \
                 --batch_size 512 \
                 --train_data datasets-knowledge-embedding/FB15K/edges_as_id_train.tsv \
                 --dev_data datasets-knowledge-embedding/FB15K/edges_as_id_valid.tsv \
                 --test_data datasets-knowledge-embedding/FB15K/edges_as_id_test.tsv \
                 --cuda 1

python3 train.py --log_dir log/fb15k/lpl-transe \
                 --learning_method lpl \
                 --num_steps 50000 \
                 --eval_every 5000 \
                 --lr 1e-2 \
                 --batch_size 512 \
                 --train_data datasets-knowledge-embedding/FB15K/edges_as_id_train.tsv \
                 --dev_data datasets-knowledge-embedding/FB15K/edges_as_id_valid.tsv \
                 --cuda 2

# good learning rate
python3 train.py --log_dir log/efl_round5_family_lr1e-2 --num_steps 50000 --eval_every 5000 --lr 1e-2

# good learning rate, efl round = 3
python3 train.py --log_dir log/family/efl_round3_lr1e-2 --num_steps 50000 --eval_every 5000 --lr 1e-2 --efl_round 3

python3 train.py --log_dir log/family/efl_round3_lr1e-2_batch_size=256 --num_steps 50000 --eval_every 5000 --lr 1e-2 --efl_round 3 --batch_size 256 --cuda 2

python3 train.py --log_dir log/family/efl_round3_lr1e-2_batch_size=512 --num_steps 50000 --eval_every 5000 --lr 1e-2 --efl_round 3 --batch_size 512 --cuda 2

# good learning rate, efl round = 1
python3 train.py --log_dir log/efl_round1_family_lr1e-2 --num_steps 50000 --eval_every 5000 --lr 1e-2 --efl_round 1

# justify the batch size issue
python3 train.py --log_dir log/efl_round1_family_lr1e-2_batch_size=512 --num_steps 50000 --eval_every 5000 --lr 1e-2 --efl_round 1 --batch_size 512

# LPL family
python train.py --learning_method=lpl --log_dir log/family/lpl --batch_size 512 --cuda 1


python3 train.py --log_dir log/WN18RR/efl_round5 \
                 --learning_method efl \
                 --batch_size 512 \
                 --train_data datasets-knowledge-embedding/WN18RR/edges_as_id_train.tsv \
                 --dev_data datasets-knowledge-embedding/WN18RR/edges_as_id_valid.tsv \
                 --test_data datasets-knowledge-embedding/WN18RR/edges_as_id_test.tsv \
                 --cuda 3

python3 train.py --log_dir log/WN18RR/lpl-transe \
                 --learning_method lpl \
                 --batch_size 512 \
                 --train_data datasets-knowledge-embedding/WN18RR/edges_as_id_train.tsv \
                 --dev_data datasets-knowledge-embedding/WN18RR/edges_as_id_valid.tsv \
                 --test_data datasets-knowledge-embedding/WN18RR/edges_as_id_test.tsv \
                 --cuda 3


python3 tast_dependent_train.py --learning_rate=1e-1 --output_dir log/learning_rate_1e-1 --device cuda:0
python3 tast_dependent_train.py --learning_rate=1e-2 --output_dir log/learning_rate_1e-2 --device cuda:1
python3 tast_dependent_train.py --learning_rate=1e-3 --output_dir log/learning_rate_1e-3 --device cuda:2
python3 tast_dependent_train.py --learning_rate=1e-4 --output_dir log/learning_rate_1e-4 --device cuda:3


python3 task_dependent_train.py --device cuda:0 --reasoning_rate 0.1 --embedding_dim 1000 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt


task_dependent_train.py --embedding_dim 100 --device cuda:1 --checkpoint_path pretrain/complex/FB15k-237-model-rank-100-epoch-100-1602503352.pt --sigma 1 --learning_rate 1e-3 --batch_size 1024 --reasoning_steps 10 --objective noisy --output_dir log/q2b


task_dependent_train.py --embedding_dim 100 --device cuda:2 --checkpoint_path pretrain/complex/FB15k-237-model-rank-100-epoch-100-1602503352.pt --sigma 1 --learning_rate 1e-2 --batch_size 32 --reasoning_steps 10 --objective none --output_dir log/test_plus_eval --model_name complexplus


python3 task_dependent_train.py --embedding_dim 100 --device cuda:0 --checkpoint_path pretrain/complex/FB15k-237-model-rank-100-epoch-100-1602503352.pt --sigma 1 --learning_rate 1e-2 --batch_size 32 --reasoning_steps 10 --objective noisy --output_dir log/test_plus --model_name complexplus


python3 task_dependent_train.py --embedding_dim 1000 --device cuda:0 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 32 --reasoning_steps 10 --objective noisy --output_dir log/train_query_train_1p_eval1kRsteps


python3 lifted_embedding_estimation_with_truth_value.py --embedding_dim 1000 --device cuda:0 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 32 --reasoner gnn --output_dir log/train_GNN_reasoner


python3 lifted_embedding_estimation_with_truth_value.py \
    --task_folder data/FB15k-237-betae \
    --embedding_dim 1000 \
    --device cuda:2 \
    --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt \
    --learning_rate 1e-5 \
    --batch_size 64 \
    --reasoner gnn \
    --output_dir log/train_GNN_reasoner_betae


python3 lifted_embedding_estimation_with_truth_value.py \
    --task_folder data/FB15k-237-betae \
    --embedding_dim 1000 \
    --device cuda:1 \
    --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt \
    --learning_rate 1e-5 \
    --batch_size 64 \
    --reasoner gnn \
    --margin 10 \
    --output_dir log/train_GNN_reasoner_betae_margin=10


python3 lifted_embedding_estimation_with_truth_value.py \
    --task_folder data/FB15k-237-betae \
    --embedding_dim 1000 \
    --device cuda:0 \
    --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt \
    --learning_rate 1e-5 \
    --batch_size 64 \
    --reasoner gnn \
    --margin 100 \
    --output_dir log/train_GNN_reasoner_betae_margin=100


python3 lifted_embedding_estimation_with_truth_value.py \
    --task_folder data/FB15k-237-betae \
    --embedding_dim 1000 \
    --device cuda:3 \
    --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt \
    --learning_rate 1e-5 \
    --batch_size 64 \
    --reasoner gnn \
    --margin 0.1 \
    --output_dir log/train_GNN_reasoner_betae_margin=01


lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:3 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-3 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/debug_gnn_reasoner

# potential version
python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:3 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 0.15 --output_dir log/debug_gnn_reasoner

python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:3 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_tv --objective tv
python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:3 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_nn --objective nn
python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:2 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_nn_inner_product --objective nn

python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:2 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_nn_temperature=0_1 --objective nn --temp 0.1

python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:2 --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_temp=0_1_margin=0_1 --objective nn --temp 0.1 --margin 0.1


python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:3 --learning_rate 1e-4 --batch_size 4096 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_temp=0_1_margin=0_1_without_pretrain --objective nn --temp 0.1 --margin 0.1

python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --embedding_dim 1000 --device cuda:0 --learning_rate 1e-4 --batch_size 1024 --reasoner gnn --margin 1 --output_dir log/train_gnn_reasoner_temp=33_margin=0_1_without_pretrain --objective nn --temp 33 --margin 0.1

ngc batch run \
 --name "ml-model.kgtvr-complex1000-default-fb15k-237" \
 --priority NORMAL \
 --preempt RUNONCE \
 --min-timeslice 0s \
 --total-runtime 0s \
 --ace nv-us-west-2 \
 --instance dgx1v.16g.1.norm \
 --result /results \
 --image "nvidia/pytorch:22.05-py3" \
 --org nvidian \
 --team sae \
 --workspace 8sr-vg7_STK0qaux2KusFA:/workspace:RW \
 --order 50
 --commandline "cd /workspace/Truth-Value-Reasoning-on-Knowledge-Graphs && python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --checkpoint_path pretrain/complex/FB15k-237-model-rank-1000-epoch-100-1602508358.pt --device cuda:0 --output_dir log/fb15k-237/pretrain_complex1000-defaults"


ngc batch run \
 --name "ml-model.kgtvr-complex1000-default-fb15k" \
 --priority NORMAL \
 --preempt RUNONCE \
 --min-timeslice 0s \
 --total-runtime 0s \
 --ace nv-us-west-2 \
 --instance dgx1v.16g.1.norm \
 --result /results \
 --image "nvidia/pytorch:22.05-py3" \
 --org nvidian \
 --team sae \
 --workspace 8sr-vg7_STK0qaux2KusFA:/workspace:RW \
 --order 50
 --commandline "cd /workspace/Truth-Value-Reasoning-on-Knowledge-Graphs && python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --checkpoint_path pretrain/complex/FB15k-model-rank-1000-epoch-100-1602520745.pt --device cuda:0 --output_dir log/fb15k/pretrain_complex1000-defaults"



ngc batch run \
 --name "ml-model.kgtvr-complex1000-default-nell" \
 --priority NORMAL \
 --preempt RUNONCE \
 --min-timeslice 0s \
 --total-runtime 0s \
 --ace nv-us-west-2 \
 --instance dgx1v.16g.1.norm \
 --result /results \
 --image "nvidia/pytorch:22.05-py3" \
 --org nvidian \
 --team sae \
 --workspace 8sr-vg7_STK0qaux2KusFA:/workspace:RW \
 --order 50
 --commandline "cd /workspace/Truth-Value-Reasoning-on-Knowledge-Graphs && python3 lifted_embedding_estimation_with_truth_value.py --task_folder data/FB15k-237-betae --checkpoint_path pretrain/complex/NELL-model-rank-1000-epoch-100-1602499096.pt --device cuda:0 --output_dir log/nell/pretrain_complex1000-defaults"
